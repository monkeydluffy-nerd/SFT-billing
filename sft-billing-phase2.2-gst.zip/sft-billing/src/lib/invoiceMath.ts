import type { Invoice, InvoiceStatusInfo } from "@/types";

/**
 * Every screen (Overview, Invoices, Clients, AURA) calls THIS function
 * rather than reading a stored status — see the note in types/invoice.ts.
 * `asOf` defaults to "now" but is a parameter so status can be computed
 * consistently against a fixed clock in tests/demos.
 */
export function getInvoiceStatus(invoice: Invoice, asOf: Date = new Date()): InvoiceStatusInfo {
  if (invoice.isDraft) {
    return { status: "draft", daysOverdue: 0, severity: null };
  }
  if (invoice.paidAt) {
    return { status: "paid", daysOverdue: 0, severity: null };
  }

  const due = new Date(invoice.dueDate);
  const msPerDay = 1000 * 60 * 60 * 24;
  const daysPastDue = Math.floor((asOf.getTime() - due.getTime()) / msPerDay);

  if (daysPastDue <= 0) {
    return { status: "pending", daysOverdue: 0, severity: null };
  }

  return {
    status: "overdue",
    daysOverdue: daysPastDue,
    severity: daysPastDue >= 30 ? "strong" : "mild",
  };
}

export interface InvoiceTotals {
  subtotal: number;
  cgstAmount: number;
  sgstAmount: number;
  discount: number;
  /** The total before round-off is applied — useful for showing "round off" as an explicit, separate line. */
  rawTotal: number;
  roundOff: number;
  total: number;
}

/**
 * The single source of truth for every number on an invoice — the
 * Overview dashboard, the Invoices list, the live Create Invoice
 * preview, and payment recording all call this instead of computing
 * their own. GST is CGST + SGST (see InvoiceGst in types/invoice.ts),
 * not one flat "tax %", and round-off is a distinct, explicit value
 * rather than folded silently into the total.
 */
export function computeInvoiceTotals(
  invoice: Pick<Invoice, "items" | "gst" | "discount" | "roundOff">,
): InvoiceTotals {
  const subtotal = invoice.items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
  const taxableValue = Math.max(0, subtotal - invoice.discount);
  const cgstAmount = taxableValue * invoice.gst.cgstRate;
  const sgstAmount = taxableValue * invoice.gst.sgstRate;
  const rawTotal = taxableValue + cgstAmount + sgstAmount;
  const roundOff = invoice.roundOff ?? 0;
  const total = Math.max(0, rawTotal + roundOff);
  return { subtotal, cgstAmount, sgstAmount, discount: invoice.discount, rawTotal, roundOff, total };
}

/**
 * The round-off value that would take `rawTotal` to the nearest whole
 * rupee — offered as a one-click suggestion in Create Invoice, never
 * applied automatically (round-off is a user decision, not a silent one).
 */
export function suggestRoundOff(rawTotal: number): number {
  return Math.round(rawTotal) - rawTotal;
}
