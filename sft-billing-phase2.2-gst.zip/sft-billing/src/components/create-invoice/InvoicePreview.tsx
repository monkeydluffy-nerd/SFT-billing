import { motion, AnimatePresence } from "framer-motion";
import type { BusinessProfile, Client, Invoice } from "@/types";
import { computeInvoiceTotals } from "@/lib/invoiceMath";
import { amountInWords } from "@/lib/amountInWords";
import { formatCurrency, formatDate } from "@/lib/formatters";

interface InvoicePreviewProps {
  invoice: Invoice;
  client: Client | undefined;
  business: BusinessProfile | undefined;
}

/**
 * Renders the invoice as it will actually look — laid out like a real
 * "Tax Invoice" (business identity + GSTIN/PAN, bill-to with the
 * client's GSTIN, optional order/delivery block, HSN-coded line items,
 * CGST/SGST/round-off broken out explicitly, amount in words, bank
 * details, and a signatory line) rather than a generic summary card.
 * This is a deliberate modern redesign of a real GST tax invoice's
 * information, not a visual copy of any reference document. Only the
 * total re-mounts on change (via the `key`), giving it a brief
 * cross-fade rather than flashing the entire document on every keystroke.
 */
export function InvoicePreview({ invoice, client, business }: InvoicePreviewProps) {
  const totals = computeInvoiceTotals(invoice);
  const hasItems = invoice.items.some((item) => item.description.trim());
  const hasOrderDetails = invoice.supplierCode || invoice.poNumber || invoice.poDate || invoice.transporter;

  return (
    <div className="mx-auto w-full max-w-[560px] rounded-lg border border-border bg-surface p-10 shadow-float">
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3">
          {business?.logoUrl && (
            <img src={business.logoUrl} alt="" className="h-10 w-10 shrink-0 rounded-md object-cover" />
          )}
          <div>
            <p className="font-display text-xl text-ink">{business?.name ?? "Your Company"}</p>
            <p className="mt-1 max-w-[220px] text-xs leading-relaxed text-ink-muted">{business?.address}</p>
            <div className="mt-1 space-y-0.5 text-xs text-ink-faint">
              {business?.gstin && <p>GSTIN: {business.gstin}</p>}
              {business?.pan && <p>PAN: {business.pan}</p>}
            </div>
          </div>
        </div>
        <div className="text-right">
          <p className="font-display text-lg text-ink">Tax Invoice</p>
          <p className="font-tabular text-sm text-ink-muted">{invoice.number}</p>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 border-y border-border py-4 text-sm">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">Billed to</p>
          <p className="mt-1 font-medium text-ink">{client?.name ?? "Select a client"}</p>
          {client && (
            <div className="mt-0.5 space-y-0.5 text-xs text-ink-muted">
              <p>{client.email}</p>
              {client.billingAddress && <p className="max-w-[200px]">{client.billingAddress}</p>}
              {client.gstin && <p>GSTIN: {client.gstin}</p>}
            </div>
          )}
        </div>
        <div className="text-right">
          <p className="text-xs text-ink-faint">
            Issued <span className="font-tabular text-ink-muted">{formatDate(invoice.issueDate)}</span>
          </p>
          <p className="mt-1 text-xs text-ink-faint">
            Due <span className="font-tabular text-ink-muted">{formatDate(invoice.dueDate)}</span>
          </p>
        </div>
      </div>

      {hasOrderDetails && (
        <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-1 border-b border-border pb-4 text-xs text-ink-muted">
          {invoice.supplierCode && (
            <p>
              <span className="text-ink-faint">Supplier code </span>
              {invoice.supplierCode}
            </p>
          )}
          {invoice.poNumber && (
            <p>
              <span className="text-ink-faint">P.O. No </span>
              {invoice.poNumber}
            </p>
          )}
          {invoice.poDate && (
            <p>
              <span className="text-ink-faint">P.O. Date </span>
              <span className="font-tabular">{formatDate(invoice.poDate)}</span>
            </p>
          )}
          {invoice.transporter && (
            <p>
              <span className="text-ink-faint">Transporter </span>
              {invoice.transporter}
            </p>
          )}
        </div>
      )}

      <div className="mt-5">
        {hasItems ? (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-ink-faint">
                <th className="w-6 pb-2 font-medium">#</th>
                <th className="pb-2 font-medium">Description</th>
                <th className="pb-2 text-right font-medium">HSN</th>
                <th className="pb-2 text-right font-medium">Qty</th>
                <th className="pb-2 text-right font-medium">Rate</th>
                <th className="pb-2 text-right font-medium">Taxable value</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {invoice.items
                .filter((item) => item.description.trim())
                .map((item, index) => (
                  <tr key={item.id}>
                    <td className="font-tabular py-2 text-ink-faint">{index + 1}</td>
                    <td className="py-2 pr-2 text-ink">{item.description}</td>
                    <td className="font-tabular py-2 text-right text-ink-muted">{item.hsnCode || "—"}</td>
                    <td className="font-tabular py-2 text-right text-ink-muted">{item.quantity}</td>
                    <td className="font-tabular py-2 text-right text-ink-muted">{formatCurrency(item.unitPrice)}</td>
                    <td className="font-tabular py-2 text-right text-ink">{formatCurrency(item.quantity * item.unitPrice)}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        ) : (
          <p className="rounded-md border border-dashed border-border py-8 text-center text-sm text-ink-faint">
            Add line items to see them here
          </p>
        )}
      </div>

      <div className="mt-5 flex justify-end">
        <div className="w-60 space-y-1.5 text-sm">
          <div className="flex justify-between text-ink-muted">
            <span>Taxable value</span>
            <span className="font-tabular">{formatCurrency(totals.subtotal - totals.discount)}</span>
          </div>
          {totals.discount > 0 && (
            <div className="flex justify-between text-ink-muted">
              <span>Discount</span>
              <span className="font-tabular">−{formatCurrency(totals.discount)}</span>
            </div>
          )}
          <div className="flex justify-between text-ink-muted">
            <span>CGST ({(invoice.gst.cgstRate * 100).toFixed(1)}%)</span>
            <span className="font-tabular">{formatCurrency(totals.cgstAmount)}</span>
          </div>
          <div className="flex justify-between text-ink-muted">
            <span>SGST ({(invoice.gst.sgstRate * 100).toFixed(1)}%)</span>
            <span className="font-tabular">{formatCurrency(totals.sgstAmount)}</span>
          </div>
          {totals.roundOff !== 0 && (
            <div className="flex justify-between text-ink-muted">
              <span>Round off</span>
              <span className="font-tabular">{totals.roundOff > 0 ? "+" : "−"}{formatCurrency(Math.abs(totals.roundOff))}</span>
            </div>
          )}
          <div className="flex justify-between border-t border-border pt-1.5 font-medium text-ink">
            <span>Grand total</span>
            <AnimatePresence mode="wait">
              <motion.span
                key={totals.total}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.15 }}
                className="font-tabular"
              >
                {formatCurrency(totals.total)}
              </motion.span>
            </AnimatePresence>
          </div>
        </div>
      </div>

      {hasItems && (
        <p className="mt-3 border-t border-border pt-3 text-right text-xs italic text-ink-faint">
          {amountInWords(totals.total)}
        </p>
      )}

      {invoice.notes && (
        <div className="mt-6 border-t border-border pt-4">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">Notes</p>
          <p className="mt-1 text-sm text-ink-muted">{invoice.notes}</p>
        </div>
      )}

      {invoice.terms && (
        <div className="mt-4">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">Declaration</p>
          <p className="mt-1 text-xs text-ink-muted">{invoice.terms}</p>
        </div>
      )}

      {business?.bank && (
        <div className="mt-6 flex items-end justify-between border-t border-border pt-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">Payment details</p>
            <div className="mt-1 space-y-0.5 text-xs text-ink-muted">
              <p>{business.bank.accountHolder}</p>
              <p>{business.bank.bankName} · {business.bank.branch}</p>
              <p>A/C {business.bank.accountNumber} · IFSC {business.bank.ifsc}</p>
            </div>
          </div>
          {business.authorizedSignatory && (
            <div className="text-right text-xs text-ink-muted">
              <p className="mb-6">For {business.name}</p>
              <p className="border-t border-border pt-1">{business.authorizedSignatory}</p>
              <p className="text-ink-faint">Authorized signatory</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
