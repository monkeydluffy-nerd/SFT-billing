import { AppShell } from "@/components/layout/AppShell";
import { OverviewPage } from "@/pages/OverviewPage";
import { useWorkspaceStore } from "@/hooks/useWorkspaceStore";

/**
 * Phase 1 only wires "overview" to real content — SidebarNav already
 * disables navigation to every other page, so `currentPage` can only
 * ever be "overview" today. This switch is written as the seam for
 * Phase 2+: each new page becomes one more case here, and nothing about
 * App or AppShell needs to change when that happens.
 */
export function App() {
  const currentPage = useWorkspaceStore((s) => s.currentPage);

  switch (currentPage) {
    case "overview":
    default:
      return (
        <AppShell>
          <OverviewPage />
        </AppShell>
      );
  }
}
