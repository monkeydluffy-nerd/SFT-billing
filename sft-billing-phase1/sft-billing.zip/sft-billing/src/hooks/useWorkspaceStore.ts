import { create } from "zustand";
import type { InvoiceStatus } from "@/types";

export type AppPage = "overview" | "invoices" | "clients" | "payments" | "intelligence" | "reports" | "settings";

/**
 * Cross-cutting UI state that more than one component needs to read or
 * change — this is intentionally NOT where invoice/client/payment data
 * lives (that's the data layer, see src/services + src/hooks/useInvoices
 * etc.). This store only ever holds ephemeral interface state:
 * navigation, the active in-page filter, and whether transient panels
 * (command palette, AURA) are open.
 */
interface WorkspaceState {
  currentPage: AppPage;
  navigateTo: (page: AppPage) => void;

  /** Drives the Overview "click a metric, the workspace transforms" interaction (blueprint §5.1). */
  overviewFocus: InvoiceStatus | null;
  focusOverviewStatus: (status: InvoiceStatus | null) => void;

  commandPaletteOpen: boolean;
  openCommandPalette: () => void;
  closeCommandPalette: () => void;

  auraOpen: boolean;
  openAura: () => void;
  closeAura: () => void;
  toggleAura: () => void;

  sidebarCollapsed: boolean;
  toggleSidebar: () => void;

  theme: "light" | "dark";
  toggleTheme: () => void;
}

export const useWorkspaceStore = create<WorkspaceState>((set, get) => ({
  currentPage: "overview",
  navigateTo: (page) => set({ currentPage: page }),

  overviewFocus: null,
  focusOverviewStatus: (status) =>
    set((state) => ({ overviewFocus: state.overviewFocus === status ? null : status })),

  commandPaletteOpen: false,
  openCommandPalette: () => set({ commandPaletteOpen: true }),
  closeCommandPalette: () => set({ commandPaletteOpen: false }),

  auraOpen: false,
  openAura: () => set({ auraOpen: true }),
  closeAura: () => set({ auraOpen: false }),
  toggleAura: () => set({ auraOpen: !get().auraOpen }),

  sidebarCollapsed: false,
  toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),

  theme: "light",
  toggleTheme: () => set((state) => ({ theme: state.theme === "light" ? "dark" : "light" })),
}));
